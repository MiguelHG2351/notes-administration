# Proyecto esta creado con C, lenguaje de bajo nivel

# comando de ejecución

- gcc home.c -o build/home.exe

- index.exe

## Se puede ejecutar en DevC++ y gcc, en dosbox no por los comentarios.

# Se iba a utilizar el modulo FILE para guardar los datos pero ocurrio un error y no hay lectura de datos

Puede ser por el compilador o la versión del lenguaje, C es muy antiguo por lo que siempre hay errores

# El único problema es que la nota no se puede obtener desde un fichero

cada vez que intento utilizar ese modulo no habre, y solo es en este proyecto

# El proyecto esta disponible en github

[Codigo en C](https://github.com/MiguelHG2351/notes-administration/tree/codigo_c)