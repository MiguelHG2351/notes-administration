#include <stdio.h>

void main() {
    printf("hOLA");
}

/* No completado */