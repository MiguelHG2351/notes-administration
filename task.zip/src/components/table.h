void table(char *name, int number) {
    int i;

    for ( i = 0; i < 4; i++)
    {
        if(number != NULL)
        printf("");
    } else {
        printf("");
    }
    
}